IJA2016 Solitaire
Autoři: Jakub Fajkus, David Czernin

Projekt je napsán v jazyce Java s použitím knihovny JavaFX.