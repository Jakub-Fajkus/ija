#!/usr/bin/env bash

wget "https://drive.google.com/open?id=0B9RIiHyAP6XzMTFIZ1RWVXEzcTQ" -O img.zip
unzip "img.zip"
rm "img.zip"